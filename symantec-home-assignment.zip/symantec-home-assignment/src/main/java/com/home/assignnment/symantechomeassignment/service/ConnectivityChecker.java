package com.home.assignnment.symantechomeassignment.service;

import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import com.home.assignnment.symantechomeassignment.model.Site;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface ConnectivityChecker {

    List<CompletableFuture<ConnectivityResult>> getResult(Set<Site> sites);

    String getType();

}
