package com.home.assignnment.symantechomeassignment.service;

import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import com.home.assignnment.symantechomeassignment.model.ConnectivitySitesConfig;
import com.home.assignnment.symantechomeassignment.service.checkers.ConnectivityFactory;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ConnectivityResultOrchestration {

    @Autowired
    private ConnectivityFactory connectivityFactory;

    public List<ConnectivityResult> getResultFor(ConnectivitySitesConfig config) throws IOException {
        List<CompletableFuture<ConnectivityResult>> dns = connectivityFactory.getFor("dns")
                .getResult(config.getDnsLockup());
        List<CompletableFuture<ConnectivityResult>> http = connectivityFactory.getFor("http")
                .getResult(config.getHttpConnectivity());
        List<CompletableFuture<ConnectivityResult>> https = connectivityFactory.getFor("https")
                .getResult(config.getHttpsConnectivity());

        return getResults(List.of(dns, http, https));
    }

    private List<ConnectivityResult> getResults(List<List<CompletableFuture<ConnectivityResult>>> results) {
        return results.stream().flatMap(Collection::stream).map(res -> {
            try {
                return res.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                return null;
            }
        }).collect(Collectors.toList());

    }

}
