package com.home.assignnment.symantechomeassignment.model;

import lombok.Data;

@Data
public class Site {
    private String site;
    private long threshold;
}
