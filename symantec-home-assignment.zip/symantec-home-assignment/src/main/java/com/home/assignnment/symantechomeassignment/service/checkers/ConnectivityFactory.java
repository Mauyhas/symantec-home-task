package com.home.assignnment.symantechomeassignment.service.checkers;

import com.home.assignnment.symantechomeassignment.service.ConnectivityChecker;
import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConnectivityFactory {

    @Autowired
    private List<ConnectivityChecker> checkers;

    public ConnectivityChecker getFor(String fileCreatorIdentifier) throws IOException {
        return checkers.stream()
                .filter(creator -> creator.getType().equals(fileCreatorIdentifier))
                .findFirst()
                .orElseThrow(() -> new IOException("Connectivity type not supported" + fileCreatorIdentifier));
    }
}
