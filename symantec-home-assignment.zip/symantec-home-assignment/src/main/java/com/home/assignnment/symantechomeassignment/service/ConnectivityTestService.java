package com.home.assignnment.symantechomeassignment.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import com.home.assignnment.symantechomeassignment.model.ConnectivitySitesConfig;
import java.io.File;
import java.io.IOException;
import java.util.List;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.NestedIOException;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;


@Service
public class ConnectivityTestService {

    @Value("classpath:configuration/site-configuration.json")
    private Resource resourceFile;

    @Autowired
    private ConnectivityResultOrchestration connectivityResultOrchestration;

    @Autowired
    private LoggerUtil log;

    @Autowired
    private ConnectivityResultPrinter connectivityResultPrinter;

    public void run() throws Exception {
        runConfigurationTest();
    }

    private void runConfigurationTest() throws Exception {
        try{
            ObjectMapper mapper = new ObjectMapper();
            ConnectivitySitesConfig config = null;
            config = mapper.readValue(new File(resourceFile.getURI()), ConnectivitySitesConfig.class);
            List<ConnectivityResult> results = connectivityResultOrchestration.getResultFor(config);
            compareResultToLastLog(config, results);
            createNewLog(results);
        }catch (Exception e){
            handleError(e);
        }

    }

    private void handleError(Exception e) throws Exception {
        printError(e.getMessage());
        throw e;
    }

    private void printError(String errorMsg) {
        System.err.println(errorMsg);
    }

    private void createNewLog(List<ConnectivityResult> results) throws IOException {
        if(results == null){
            handleNullResults();
        }
        log.printOutputToLog(results);
    }

    private void handleNullResults() throws NestedIOException {
        printError("Fail to get results, check logs!");
        throw new NestedIOException("Fail to get results, check logs!");
    }

    private void compareResultToLastLog(ConnectivitySitesConfig config, List<ConnectivityResult> results)
            throws IOException {
        if(results == null){
            handleNullResults();
        }
        connectivityResultPrinter.printResults(config, results);
    }

}
