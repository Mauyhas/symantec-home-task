package com.home.assignnment.symantechomeassignment.model;

import java.util.Set;
import lombok.Data;

@Data
public class ConnectivitySitesConfig {

    private Set<Site> dnsLockup;
    private Set<Site> httpConnectivity;
    private Set<Site> httpsConnectivity;

}
