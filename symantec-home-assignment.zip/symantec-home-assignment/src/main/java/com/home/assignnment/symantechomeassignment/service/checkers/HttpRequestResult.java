package com.home.assignnment.symantechomeassignment.service.checkers;

import com.home.assignnment.symantechomeassignment.model.Site;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;
import org.springframework.util.StopWatch;

public class HttpRequestResult {

    private static final HttpClient httpClient = HttpClient.newBuilder()
            .version(Version.HTTP_2)
            .build();

    public CompletableFuture<ConnectivityResult> getSiteResultFuture(Site site, String method) {
        return CompletableFuture.supplyAsync(() -> getSiteResult(site, method));
    }

    private ConnectivityResult getSiteResult(Site site, String method){
        StopWatch stopWatch = new StopWatch();
        ConnectivityResult result = new ConnectivityResult();
        result.setSiteName(site.getSite());
        result.setMethod(method);
        HttpRequest request = HttpRequest.newBuilder()
                .GET()
                .uri(URI.create(site.getSite()))
                .build();
        try{
            stopWatch.start("Http check for: " + site);
            httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            stopWatch.stop();
            result.setTime(stopWatch.getLastTaskTimeMillis());
            result.setConnectivityCheck(true);
        }catch (Exception e){
            result.setConnectivityCheck(false);
        }
        System.out.println(stopWatch.prettyPrint());
        return result;

    }
}
