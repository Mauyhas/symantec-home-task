package com.home.assignnment.symantechomeassignment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class LoggerUtil {

    private final String LOG_FILE_NAME = "log.log";

    public void printOutputToLog(List<ConnectivityResult> results) throws IOException {
        try {
            // the following statement is used to log any messages
            ObjectMapper objectMapper = new ObjectMapper();
            String jsonString = objectMapper.writeValueAsString(results);
            RandomAccessFile writer = new RandomAccessFile(LOG_FILE_NAME, "rw");
            writer.seek(0);
            writer.write(jsonString.getBytes(StandardCharsets.UTF_8));
            writer.close();
        } catch (SecurityException | JsonProcessingException e) {
            e.printStackTrace();
        }
    }

    public String readFromPosition() {
        try{
            RandomAccessFile reader = new RandomAccessFile(LOG_FILE_NAME, "r");
            reader.seek(0);
            String result = reader.readLine();
            reader.close();
            return result;
        }catch (Exception e){
            System.out.println("No last run, no logs to compare threshold");
            return null;
        }

    }

}
