package com.home.assignnment.symantechomeassignment.model;

import lombok.Data;

@Data
public class ConnectivityResult {
    private boolean connectivityCheck;
    private long time;
    private String siteName;
    private String method;
}
