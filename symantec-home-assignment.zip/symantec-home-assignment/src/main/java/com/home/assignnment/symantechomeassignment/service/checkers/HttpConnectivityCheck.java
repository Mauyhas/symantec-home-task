package com.home.assignnment.symantechomeassignment.service.checkers;

import com.home.assignnment.symantechomeassignment.model.Site;
import com.home.assignnment.symantechomeassignment.service.ConnectivityChecker;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

@Service
public class HttpConnectivityCheck extends HttpRequestResult implements ConnectivityChecker {

    @Override
    public List<CompletableFuture<ConnectivityResult>> getResult(Set<Site> sites) {
        return sites.stream().map(site -> getSiteResultFuture(site, "http")).collect(Collectors.toList());
    }

    @Override
    public String getType() {
        return "http";
    }
}
