package com.home.assignnment.symantechomeassignment;

import com.home.assignnment.symantechomeassignment.service.ConnectivityTestService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SymantecHomeAssignmentApplication implements CommandLineRunner {

    @Autowired
    private ConnectivityTestService connectivityTestService;

    public static void main(String[] args) {
        SpringApplication.run(SymantecHomeAssignmentApplication.class, args);
    }

    @Override
    public void run(String... args) {
        try{
            connectivityTestService.run();
        }catch (Exception e){
            System.err.println(e.getMessage());
        }
    }
}
