package com.home.assignnment.symantechomeassignment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import com.home.assignnment.symantechomeassignment.model.ConnectivitySitesConfig;
import com.home.assignnment.symantechomeassignment.model.Site;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConnectivityResultPrinter {

    @Autowired
    private LoggerUtil log;


    public void printResults(ConnectivitySitesConfig config, List<ConnectivityResult> results)
            throws JsonProcessingException {
        printResultsPretty(results);
        String lastLogPrint = log.readFromPosition();
        if(lastLogPrint != null){
            ObjectMapper mapper = new ObjectMapper();
            ConnectivityResult[] connectivityResults = mapper.readValue(lastLogPrint, ConnectivityResult[].class);
            List<ConnectivityResult> lastLogResult = Arrays.asList(connectivityResults);
            compare(results, lastLogResult, config);
        }else{
            System.out.println("No last log file available to compare!");
        }
    }

    private void printResultsPretty(List<ConnectivityResult> results) {
        results.forEach(this::print);

    }

    private void print(ConnectivityResult res) {
        StringBuilder resultSb = new StringBuilder();
        if(res.isConnectivityCheck()){
            resultSb.append("Successfully performed ");
        }else{
            resultSb.append("ALERT: Failed to preformed ");
        }
        resultSb.append(res.getMethod()).append(" to: ").append(res.getSiteName());
        System.out.println(resultSb);

    }

    private void compare(List<ConnectivityResult> results, List<ConnectivityResult> lastLogResult,
            ConnectivitySitesConfig config) {
        Map<String, Long> mapSiteToTiming = lastLogResult.stream()
                .collect(Collectors.toMap(ConnectivityResult::getSiteName, ConnectivityResult::getTime));
        Map<String, Long> configThreshold = Stream
                .of(config.getHttpsConnectivity().stream(), config.getHttpConnectivity().stream())
                .map(site -> site.collect(Collectors.toList()))
                .flatMap(List::stream)
                .collect(Collectors.toMap(Site::getSite, Site::getThreshold));
        results.forEach(res -> printThresholdViolations(res, mapSiteToTiming.get(res.getSiteName()), configThreshold.get(res.getSiteName())));
    }

    private void printThresholdViolations(ConnectivityResult result, Long lastTiming, Long threshold) {
        if(threshold != null){
            long thresholdInSec = threshold * 1000; // 1 threshold = 1 sec
            if(result.getTime() + thresholdInSec > lastTiming){
                System.err.println(result.getSiteName() + " connectivity check took too long: timing: "  + result.getTime() + " threshold:" + threshold + "(Seconds)");
            }
        }

    }

}
