package com.home.assignnment.symantechomeassignment.service.checkers;

import com.home.assignnment.symantechomeassignment.model.Site;
import com.home.assignnment.symantechomeassignment.service.ConnectivityChecker;
import com.home.assignnment.symantechomeassignment.model.ConnectivityResult;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

@Service
public class DNSConnectivityChecker implements ConnectivityChecker {

    @Override
    public List<CompletableFuture<ConnectivityResult>> getResult(Set<Site> sites) {
        return sites.stream().map(this::getSiteResult).collect(Collectors.toList());

    }

    private CompletableFuture<ConnectivityResult> getSiteResult(Site site) {
        return CompletableFuture.supplyAsync(() -> getConnectivityResult(site));
    }

    private ConnectivityResult getConnectivityResult(Site site) {
        ConnectivityResult result = new ConnectivityResult();
        result.setSiteName(site.getSite());
        result.setMethod("DNS");
        StopWatch stopWatch = new StopWatch();
        try {
            stopWatch.start("DNS check for: " + site);
            InetAddress.getByName(site.getSite());
            stopWatch.stop();
            result.setTime(stopWatch.getTotalTimeMillis());
            result.setConnectivityCheck(true);
            System.out.println(stopWatch.prettyPrint());
        } catch (UnknownHostException e) {
            System.out.println(e.fillInStackTrace());
            result.setConnectivityCheck(false);
        }
        return result;
    }

    @Override
    public String getType() {
        return "dns";
    }
}
