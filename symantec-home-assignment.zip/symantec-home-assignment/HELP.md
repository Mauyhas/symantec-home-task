# Getting Started

### Reference Documentation

###Build command -> mvn clean package

###Running the app -> java -jar symantec-home-assignment.jar

###Config file can be edited under resources/configuration.json